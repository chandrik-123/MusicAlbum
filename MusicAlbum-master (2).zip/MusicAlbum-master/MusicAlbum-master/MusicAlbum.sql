
//Database Creation//

create database music_album_db;
use music_album_db;
---------------------------------------
//Tables creation//
create table AlbumTypeMaste
(Album_id int(11) not null auto_increment,
album_name varchar(20),
year int(4), PRIMARY KEY(Album_id)
);
---------------------------------
//Alter table name//
ALTER TABLE AlbumTypeMaste RENAME AlbumTypeMaster;
-----------------------------
create table TitleMaste
(title_id int(11) not null auto_increment,
title_name varchar(20),
 PRIMARY KEY(title_id)
);
---------------------------------
//Alter table name//
ALTER TABLE TitleMaste RENAME TitleMaster;
---------------------------------
create table ArtistMaster
(artist_id int(11) not null auto_increment,
artist_name varchar(20),
profession varchar(20),
primary key(artist_id));

create table GenreMaster
(genre_id int(11) not null auto_increment,
genere_name varchar(20),
primary key(genre_id));

----------------------------------------
create table MusicMaste
(music_id int(11) not null auto_increment,
album_id int(10),FOREIGN KEY (album_id)
        REFERENCES AlbumTypeMaste(Album_id),
title_id int(10),FOREIGN KEY (title_id)
        REFERENCES TitleMaste(title_id),
artist_id int(10),FOREIGN KEY (artist_id)
        REFERENCES ArtistMaster(artist_id),
genre_id int(10),FOREIGN KEY (genre_id)
        REFERENCES GenreMaster(genre_id),
primary key(music_id));
-------------------------------------
//Alter Table Name//
ALTER TABLE MusicMaste RENAME MusicMaster;
-------------------------------------

Stored Procedures
--------------------------------------------------------
Albumtypemaster for Insert
----------------------------
CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_spAlbumtypemaster`(IN iAlbum_id int(11),IN ialbum_name varchar(20),IN iyear int(4))
BEGIN
IF NOT EXISTS (select Album_id from music_album_db.albumtypemaster
 where Album_id = iAlbum_id) THEN
INSERT INTO music_album_db.albumtypemaster
(Album_id,album_name,year)
VALUES (iAlbum_id,ialbum_name,iyear);

BEGIN
-- exit if the duplicate key occurs
SELECT CONCAT('Duplicate key (',iAlbum_id,',',ialbum_name,',',iyear,') occurred') AS message;
END;
END IF;
END

---------------------------------------------------------------------------------------------
update
--------------------------
CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_spAlbumtypemaster`( IN iAlbum_id int(11),
IN ialbum_name varchar(20),
IN iyear int(4))
BEGIN
    UPDATE music_album_db.albumtypemaster
   SET
    album_name = ialbum_name,
    year=iyear WHERE Album_id = iAlbum_id;
    END
--------------------------------------------------------------------------------------
Delete
--------------------------------------------------------
CREATE DEFINER=`root`@`localhost` PROCEDURE `Delete_spAlbumtypemaster`(IN iAlbum_id int(11),IN ialbum_name varchar(20),IN iyear int)
BEGIN
IF EXISTS (select Album_id from music_album_db.albumtypemaster
 where Album_id = iAlbum_id)
THEN

UPDATE music_album_db.albumtypemaster
  SET album_name = ialbum_name,
  year = iyear
where Album_id = iAlbum_id;
END IF;
END
----------------------------------------------------------------------------------
select by ID
-----------------------------------------
CREATE DEFINER=`root`@`localhost` PROCEDURE `Getbyalbumname_spalbumtypemaster`(IN iAlbum_id int(11))
BEGIN
SELECT *
  from music_album_db.albumtypemaster where Album_id = iAlbum_id;
END
----------------------------------------------------------------
Select ALL
-------------------------------------------
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllalbumtypemaster`()
BEGIN
Select * from music_album_db.albumtypemaster;
END