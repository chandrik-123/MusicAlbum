﻿using MusiAlbum.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusiAlbum.API.Business.Abstract
{
   public interface IAlbumTypeMasterContext
    {
        Task<int> SaveAlbumTypeMaster(AlbumTypeMaster albumTypeMaster);
        Task<int> DeleteAlbumTypeMaster(AlbumTypeMaster albumTypeMaster);
        Task<int> ModifyAlbumTypeMaster(AlbumTypeMaster albumTypeMaster);
        Task<List<AlbumTypeMaster>> GetAllAlbumTypeMaster();
        Task<AlbumTypeMaster> GetAlbumTypeMaster(int Album_id);
    }
}
