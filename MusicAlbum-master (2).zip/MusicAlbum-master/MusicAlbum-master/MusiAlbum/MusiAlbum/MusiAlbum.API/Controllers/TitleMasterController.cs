﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;

namespace MusiAlbum.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TitleMasterController : ControllerBase
    {
        private readonly ITitleMaster _titleMaster;
        public TitleMasterController(ITitleMaster title)
        {
            _titleMaster = title;
        }
        [HttpPost("SaveTitle")]
        public async Task<IActionResult> SaveTitle(TitleMasters title)
        {
            var result = await _titleMaster.SaveTitleMaster(title);

            return Ok(new { status = 200, success = true, result });
        }
        [HttpPost("UpdateTitle")]
        public async Task<IActionResult> UpdateTitle(TitleMasters title)
        {
            var result = await _titleMaster.UpdateTitleMaster(title);

            return Ok(new { status = 200, success = true, result });
        }
        [HttpPost("DeleteTitle")]
        public async Task<IActionResult> DeleteTitle(TitleMasters title)
        {
            var result = await _titleMaster.DeleteTitleMaster(title);

            return Ok(new { status = 200, success = true, result });
        }
        [HttpGet("GetTitles")]
        public async Task<IActionResult> GetTitle()
        {
            var result = await _titleMaster.GetTitles();

            return Ok(new { status = 200, success = true, result });
        }
    }
}
