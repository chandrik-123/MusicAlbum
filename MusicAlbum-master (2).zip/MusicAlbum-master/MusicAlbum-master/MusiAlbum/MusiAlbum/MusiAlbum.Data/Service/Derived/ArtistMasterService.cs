﻿using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.Serialization.Formatters;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Derived
{
    public class ArtistMasterService : IArtsitMasterService
    {
        private readonly IMySqlConnectionService _mySqlConnectionService;
        // private readonly MySqlConnectionService mySqlConnectionService;

        //public string Message { get; set; }

        public ArtistMasterService(IMySqlConnectionService mySqlConnectionService)
        {
            this._mySqlConnectionService = mySqlConnectionService;
            //mySqlConnectionService = sq;

        }



        public Task<ArtistMaster> GetArtistMaster(int artist_id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<ArtistMaster>> GetArtests()
        {
            List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
            List<ArtistMaster> artistMasters = new List<ArtistMaster>();
            ArtistMaster artistmaster = null;
            try
            {
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iQuery", 1));
                MySqlDataReader mySqlDataReader = await _mySqlConnectionService.GetDataReader("getdata", mySqlParameters).ConfigureAwait(false);
                while (mySqlDataReader.Read())
                {
                    artistmaster = new ArtistMaster
                    {
                        artist_id = Convert.ToInt32(mySqlDataReader["artist_id"]),
                        artist_name = Convert.ToString(mySqlDataReader["artist_name"]),
                        profession = Convert.ToString(mySqlDataReader["profession"]),
                    };
                    artistMasters.Add(artistmaster);
                }
                mySqlDataReader.Close();
                mySqlDataReader.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
            return artistMasters;
        }

        public async Task<string> SaveArtistMaster(ArtistMaster artistMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iartistid", artistMaster.artist_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iartistname", artistMaster.artist_name));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iprofession", artistMaster.profession));

                _mySqlConnectionService.OutParamName = "oMessage";
                mySqlParameters.Add(_mySqlConnectionService.GetParameterOut("oMessage", MySqlDbType.VarChar, null, ParameterDirection.Output));
                string messages = string.Empty;

                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iQuery", 1));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("sp_InsertUpdateDeleteFor_ArtistMaster", mySqlParameters).ConfigureAwait(false);
                return _mySqlConnectionService.Message;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<string> SaveMusicMaster(MusicMaster master)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("imusic_id", master.music_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ialbum_id", master.album_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iartist_id", master.artist_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("igenre_id", master.genre_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ititle_id", master.title_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameterOut("oMessage", MySqlDbType.VarChar, null, ParameterDirection.Output));
                string messages = string.Empty;
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Sp_InsertMusicMaster", mySqlParameters).ConfigureAwait(false);
                return _mySqlConnectionService.Message;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<string> UpdateArtistMaster(ArtistMaster artistMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iartistid", artistMaster.artist_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iartistname", artistMaster.artist_name));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iprofession", artistMaster.profession));
                mySqlParameters.Add(_mySqlConnectionService.GetParameterOut("oMessage", MySqlDbType.VarChar, null, ParameterDirection.Output));
                string messages = string.Empty;
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iQuery", 2));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("sp_InsertUpdateDeleteFor_ArtistMaster", mySqlParameters).ConfigureAwait(false);
                return _mySqlConnectionService.Message;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<string> DeleteArtistMaster(ArtistMaster artistMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iartistid", artistMaster.artist_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iartistname", artistMaster.artist_name));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iprofession", artistMaster.profession));
                mySqlParameters.Add(_mySqlConnectionService.GetParameterOut("oMessage", MySqlDbType.VarChar, null, ParameterDirection.Output));
                string messages = string.Empty;
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iQuery", 3));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("sp_InsertUpdateDeleteFor_ArtistMaster", mySqlParameters).ConfigureAwait(false);
                return _mySqlConnectionService.Message;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
