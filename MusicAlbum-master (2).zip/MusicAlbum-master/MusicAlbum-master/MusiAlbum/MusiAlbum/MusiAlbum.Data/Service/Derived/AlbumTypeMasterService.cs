﻿using Microsoft.Extensions.Configuration;
using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Derived
{
    public class AlbumTypeMasterService : IAlbumTypeMasterService
    {
        private readonly IConfiguration _configuration;
        private readonly IMySqlConnectionService _mySqlConnectionService;
        public AlbumTypeMasterService(IConfiguration configuration, IMySqlConnectionService mySqlConnectionService)
        {
            _configuration = configuration;
            _mySqlConnectionService = mySqlConnectionService;
        }

        public async Task<int> SaveAlbumTypeMaster(AlbumTypeMaster albumTypeMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iAlbum_id", albumTypeMaster.Album_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ialbum_name", albumTypeMaster.album_name));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iyear", albumTypeMaster.year));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Insert_spAlbumtypemaster", mySqlParameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inserted;
        }
       
        public async Task<int> DeleteAlbumTypeMaster(AlbumTypeMaster albumTypeMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iAlbum_id", albumTypeMaster.Album_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ialbum_name", albumTypeMaster.album_name));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iyear", albumTypeMaster.year));

                inserted = await _mySqlConnectionService.ExecuteNonQuery("Delete_spAlbumtypemaster", mySqlParameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inserted;
        }

        public async Task<int> ModifyAlbumTypeMaster(AlbumTypeMaster albumTypeMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iAlbum_id", albumTypeMaster.Album_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ialbum_name", albumTypeMaster.album_name));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iyear", albumTypeMaster.year));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Update_spAlbumtypemaster", mySqlParameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inserted;
        }

        public async Task<List<AlbumTypeMaster>> GetAllAlbumTypeMaster()
        {
            List<AlbumTypeMaster> albumTypeMasters = new List<AlbumTypeMaster>();
            AlbumTypeMaster albumTypeMaster = null;
            try
            {
                MySqlDataReader mySqlDataReader = await _mySqlConnectionService.GetDataReader("GetAllalbumtypemaster", null).ConfigureAwait(false);
                while (mySqlDataReader.Read())
                {
                    albumTypeMaster = new AlbumTypeMaster
                    {
                        Album_id = Convert.ToInt32(mySqlDataReader["Album_id"]),
                        album_name = Convert.ToString(mySqlDataReader["album_name"]),
                        year = Convert.ToInt32(mySqlDataReader["year"]),
                    };
                    albumTypeMasters.Add(albumTypeMaster);
                }
                mySqlDataReader.Close();
                mySqlDataReader.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
            return albumTypeMasters;
        }

        public async Task<AlbumTypeMaster> GetAlbumTypeMaster(int Album_id)
        {

            AlbumTypeMaster albumTypeMaster = null;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iAlbum_id", Album_id));
                MySqlDataReader mySqlDataReader = await _mySqlConnectionService.GetDataReader("Getbyalbumname_spalbumtypemaster", mySqlParameters).ConfigureAwait(false);
                while (mySqlDataReader.Read())
                {
                    albumTypeMaster = new AlbumTypeMaster();
                    albumTypeMaster.Album_id = Convert.ToInt32(mySqlDataReader["Album_id"]);
                    albumTypeMaster.album_name = Convert.ToString(mySqlDataReader["album_name"]);
                    albumTypeMaster.year = Convert.ToInt32(mySqlDataReader["year"]);

                }
                mySqlDataReader.Close();
                mySqlDataReader.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
            return albumTypeMaster;
        }
    }
}
