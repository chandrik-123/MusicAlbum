﻿using MusiAlbum.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Abstract
{
   public interface IArtsitMasterService
    {
        Task<string> SaveArtistMaster(ArtistMaster artistMaster);
        Task<string> DeleteArtistMaster(ArtistMaster artistMaster);
        Task<string> UpdateArtistMaster(ArtistMaster artistMaster);
        Task<List<ArtistMaster>> GetArtests();
        Task<ArtistMaster> GetArtistMaster(int artist_id);
        Task<string> SaveMusicMaster(MusicMaster musicMaster);
        Task<string> GetArtistMasterBaseduponName(string artistname);

    }
}
