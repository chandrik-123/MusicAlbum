﻿using MusiAlbum.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Abstract
{
   public interface IAlbumTypeMasterService
    {
        Task<int> SaveAlbumTypeMaster(AlbumTypeMaster albumTypeMaster);
        Task<int> DeleteAlbumTypeMaster(AlbumTypeMaster albumTypeMaster);
        Task<int> ModifyAlbumTypeMaster(AlbumTypeMaster albumTypeMaster);
        Task<List<AlbumTypeMaster>> GetAllAlbumTypeMaster();
        Task<AlbumTypeMaster> GetAlbumTypeMaster(int Album_id);
    }
}
