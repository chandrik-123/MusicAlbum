﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusiAlbum.Data.Models
{
    public class TitleMasters
    {
        public int title_id { get; set; }
        public string title_name {get;set;}
    }
}
